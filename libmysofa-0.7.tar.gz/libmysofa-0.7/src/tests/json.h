void printJson(FILE *out, struct MYSOFA_HRTF *hrtf);
